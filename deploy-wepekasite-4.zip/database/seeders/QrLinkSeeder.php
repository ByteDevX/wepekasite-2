<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\QrLink;
use App\Models\User;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Storage;

class QrLinkSeeder extends Seeder
{
    public function run(): void
    {
    }
}
